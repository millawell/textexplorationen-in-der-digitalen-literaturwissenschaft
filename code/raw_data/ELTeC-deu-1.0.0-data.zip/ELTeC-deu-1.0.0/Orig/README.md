# ELTeC-deu
Folder for the original data (all available input formats).